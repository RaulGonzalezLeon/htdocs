<?php
$rows = 5;
$colums = 6;
$i = 1;

for($i = 1; $i <= 3; $i++){
    $filas = $rows * $i;
    for($i = 1; $i <= 3; $i++){
        $columnas = $colums * $i;
    }
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej2 RaulGL</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <table>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>

    </table>

</body>
</html>